Created: December 2005
Updated: March 28, 2008

Small Area Estimates Poverty and Inequality (SAEPI) database

Contents:

DESCRIPTION
CITATION
SOURCE DATA
DATA RESTRICTIONS
NOTES/ADDITIONAL RESTRICTIONS
DATA ERRORS, CORRECTIONS AND QUALITY ASSESSMENT
NO WARRANTY OR LIABILITY
FILE TYPE
FIELDS
MISSING DATA
POVERTY LINE

DESCRIPTION

Enclosed are data from CIESIN's Small Area Estimates of Poverty and Inequality (SAEPI) database. Documentation for these data is available on the CIESIN Poverty Mapping web site at: http://sedac.ciesin.columbia.edu/povmap

This is the first version (Version 1.0) of the SAEPI product. See the Poverty Mapping home page for additional information on the product.

CITATION

We recommend the following for citing the database:

Center for International Earth Science Information Network (CIESIN), Columbia University, 2005. Small Area Estimates of Poverty and Inequality (SAEPI) database. 
Palisades, NY: CIESIN, Columbia University. Available at http://sedac.ciesin.columbia.edu/povmap. 
[We recommend that you include the original source data, country, input census year, SEAPI version number ( Version 1.0), and the date of your download here.]

SOURCE DATA
Data from the following sources were used to construct this dataset:


Guatemala
Source: World Bank
Citation: 
For 1994 Poverty data: Secretaria de Planificacion y Programacion (SEGEPLAN). (2001). Mapas de Pobreza: Informe Final, pp. 124.

For 2002 Poverty data: Secretaria de Planificacion y Programacion (SEGEPLAN). (2005). Mapas de Pobreza y desigualded de Guatemala, pp. 45.

Changes to the source data are noted in the Small Area Estimate catalog available at http://sedac.ciesin.columbia.edu/povmap/ds_info.html

DATA RESTRICTIONS

These data are for noncommercial use only. No third party distribution of all, or parts, of the electronic files is authorized. The data used in the creation of this dataset were provided to CIESIN by the organizations identified in the source data.

NOTES/ADDITIONAL RESTRICTIONS


Guatemala 1994
Restrictions: Can be redistributed with citation

Guatemala 2002
Restrictions: Can be redistributed with citation

DATA ERRORS, CORRECTIONS AND QUALITY ASSESSMENT

CIESIN follows procedures designed to ensure that data disseminated by CIESIN are of reasonable quality. If, despite these procedures, users encounter apparent errors or misstatements in the data, please contact CIESIN Customer Services at 845/365-8920 or via Internet e-mail at ciesin.info@ciesin.columbia.edu. Neither CIESIN nor NASA verifies or guarantees the accuracy, reliability, or completeness of any data provided.

NO WARRANTY OR LIABILITY

CIESIN provides this data without any warranty, either express or implied. CIESIN shall not be liable for incidental, consequential, or special damages arising out of the use of any data provided by CIESIN.

FILE TYPE

The file is in comma separated variable format (csv). This is a tabular data format that can be used in spreadsheet, database and GIS applications.

FIELDS

For a description of available fields, for a given country and administrative level, please see the Small Area Estimate Datasets catalog available at http://sedac.ciesin.columbia.edu/povmap/ds_info.html

MISSING DATA

Blank spaces in fields indicate missing data values.

POVERTY LINE

The following is a summary of the poverty line(s) used by data providers in the construction of poverty estimates:

Guatemala
Currency: Quetzal 
Value: 
The value for 1994 Poverty data is The value is: 4233 per capita per year (full poverty line) (From World Bank (2003) Poverty in Guatemala, Report No. 24221,Annex 3. http://www-wds.worldbank.org/servlet/WDSContentServer/WDSP/IB/2003/04/05/000094946_03032104003172/Rendered/PDF/multi0page.pdf)

The value for 2002 Poverty data is The value is  4,318 per capita per person per year  (From Secretaria de Planificacion y Programacion (SEGEPLAN). (2005). Mapas de Pobreza y desigualded de Guatemala, pp. 48. http://www.segeplan.gob.gt/docs/ERP/VERSIONFINAL-PUBLICACIONMAPA2002.pdf)

Alternate Poverty Line: 
The value for 1994 Poverty data is The value is: 1869 per capita per year (extreme poverty line) (From World Bank (2003) Poverty in Guatemala, Report No. 24221,Annex 3. http://www-wds.worldbank.org/servlet/WDSContentServer/WDSP/IB/2003/04/05/000094946_03032104003172/Rendered/PDF/multi0page.pdf)

The value for 2002 Poverty data is The value is  1911 per capita per person per year  (From Secretaria de Planificaci?n y Programaci?n (SEGEPLAN). (2005). Mapas de Pobreza y desigualded de Guatemala, pp. 48. http://www.segeplan.gob.gt/docs/ERP/VERSIONFINAL-PUBLICACIONMAPA2002.pdf)



