Created: December 2005
Updated: March 28, 2008

Small Area Estimates Poverty and Inequality (SAEPI) database

Contents:

DESCRIPTION
CITATION
SOURCE DATA
DATA RESTRICTIONS
NOTES/ADDITIONAL RESTRICTIONS
DATA ERRORS, CORRECTIONS AND QUALITY ASSESSMENT
NO WARRANTY OR LIABILITY
FILE TYPE
FIELDS
MISSING DATA
POVERTY LINE

DESCRIPTION

Enclosed are data from CIESIN's Small Area Estimates of Poverty and Inequality (SAEPI) database. Documentation for these data is available on the CIESIN Poverty Mapping web site at: http://sedac.ciesin.columbia.edu/povmap

This is the first version (Version 1.0) of the SAEPI product. See the Poverty Mapping home page for additional information on the product.

CITATION

We recommend the following for citing the database:

Center for International Earth Science Information Network (CIESIN), Columbia University, 2005. Small Area Estimates of Poverty and Inequality (SAEPI) database. 
Palisades, NY: CIESIN, Columbia University. Available at http://sedac.ciesin.columbia.edu/povmap. 
[We recommend that you include the original source data, country, input census year, SEAPI version number ( Version 1.0), and the date of your download here.]

SOURCE DATA
Data from the following sources were used to construct this dataset:


Honduras
Source: Inter American Development Bank (IADB)
Citation: Robles, M. in collaboration with BID/SDS/POV/MECOVI - INE Honduras (2003)."Estimacion de Indicadores de pobreza y desigualdad a nivel municipal en Honduras", pp. 44.

Changes to the source data are noted in the Small Area Estimate catalog available at http://sedac.ciesin.columbia.edu/povmap/ds_info.html

DATA RESTRICTIONS

These data are for noncommercial use only. No third party distribution of all, or parts, of the electronic files is authorized. The data used in the creation of this dataset were provided to CIESIN by the organizations identified in the source data.

NOTES/ADDITIONAL RESTRICTIONS


Honduras
Restrictions: Can be redistributed with citation

DATA ERRORS, CORRECTIONS AND QUALITY ASSESSMENT

CIESIN follows procedures designed to ensure that data disseminated by CIESIN are of reasonable quality. If, despite these procedures, users encounter apparent errors or misstatements in the data, please contact CIESIN Customer Services at 845/365-8920 or via Internet e-mail at ciesin.info@ciesin.columbia.edu. Neither CIESIN nor NASA verifies or guarantees the accuracy, reliability, or completeness of any data provided.

NO WARRANTY OR LIABILITY

CIESIN provides this data without any warranty, either express or implied. CIESIN shall not be liable for incidental, consequential, or special damages arising out of the use of any data provided by CIESIN.

FILE TYPE

The file is in comma separated variable format (csv). This is a tabular data format that can be used in spreadsheet, database and GIS applications.

FIELDS

For a description of available fields, for a given country and administrative level, please see the Small Area Estimate Datasets catalog available at http://sedac.ciesin.columbia.edu/povmap/ds_info.html

MISSING DATA

Blank spaces in fields indicate missing data values.

POVERTY LINE

The following is a summary of the poverty line(s) used by data providers in the construction of poverty estimates:

Honduras
Currency: Lempiras
Value: The value is: 1321.1 (income) per capita per month, corresponding to July 2001, for urban areas; and 706.6 per capita per month, corresponding to July 2001, for rural areas. Robles, M. in collaboration with BID/SDS/POV/MECOVI - INE Honduras (2003)."Estimacion de Indicadores de pobreza y desigualdad a nivel municipal en Honduras", pp. 44.
Alternate Poverty Line: The value is: 661.5 (income) per capita per month, corresponding to July 2001, for urban areas; and 529.2 per capita per month, corresponding to July 2001, for rural areas. Robles, M. in collaboration with BID/SDS/POV/MECOVI - INE Honduras (2003)."Estimacion de Indicadores de pobreza y desigualdad a nivel municipal en Honduras", pp. 44.



