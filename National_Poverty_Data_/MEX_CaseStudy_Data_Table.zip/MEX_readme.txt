Mexico Case Study.
Metadata also available as

Frequently-anticipated questions:

    * What does this data set describe?
         1. How should this data set be cited?
         2. What geographic area does the data set cover?
         3. What does it look like?
         4. Does the data set describe conditions during a particular time period?
         5. What is the general form of this data set?
         6. What fields does the data set contain? 
    * Who produced the data set?
         1. Who are the originators of the data set?
         2. Who also contributed to the data set?
         3. To whom should users address questions about the data? 
    * Why was the data set created?
    * How was the data set created?
         1. From what previous works were the data drawn?
         2. How were the data generated, processed, and modified?
         3. What similar or related data should the user be aware of?
    * How can someone get a copy of the data set?
         1. Are there legal restrictions on access or use of the data?
         2. Who distributes the data?
         3. What's the catalog number I need to order this data set?
         4. What legal disclaimers am I supposed to read?
         5. How can I download or order the data? 
    * Who wrote the metadata? 

What does this data set describe?

Title: Mexico Case Study 
Abstract:
    The layer is a selection from the mex_municipio_pov_model where the predicted total monthly expenditure for rural housholds in 2000 was below 485.71 pesos, PRGTOT00 

   1. How should this data set be cited?

          CIMMYT, June 2004, Mexican municipalities below food poverty line, year 2000..

          Online Links:
              * <http://www.cimmyt.org/GIS/povertymexico> 

      Other_Citation_Details:
          Geospatial Dimensions of Poverty and Food Security - A Case Study of Mexico. 2004. M.R. Bellon, D.P. Hodson, E. Martinez-Romero, Y. Montoya, J. Becceril, and J.W. White. CIMMYT project report. 

   2. What geographic area does the data set cover?

      West_Bounding_Coordinate: -108.037314
      East_Bounding_Coordinate: -87.366428
      North_Bounding_Coordinate: 28.103226
      South_Bounding_Coordinate: 14.531865

   3. What does it look like?

      <http://gisweb.ciat.cgiar.org/metadata/gifs/mexico_foodPoverty.gif> (GIF)
          Food Poverty line (2000). Mexican municipalities 

   4. Does the data set describe conditions during a particular time period?

      Calendar_Date: June 2004
      Currentness_Reference: publication date

   5. What is the general form of this data set?

      Comma Separated Values File 

    
   6. What fields does the data set contain? 
   
      For a description of available fields please see the Poverty and Food Security catalog 
      available at http://www.ciesin.columbia.edu/povmap/datasets/ds_nat_all1.jsp

Who produced the data set?

   1. Who are the originators of the data set? (may include formal authors, digital compilers, and editors)

          * CIMMYT 

   2. Who also contributed to the data set?

   3. To whom should users address questions about the data?

      Dave Hodson
      CIMMYT
      Head of GIS unit
      CIMMYT, Apdo Postal 6-641
      Mexico, D.F. C.P. 06600
      Mexico

      52 55 5804 2004 (voice)
      52 55 5804 7558 (FAX)
      d.hodson@cgiar.org

Why was the data set created?

    To highlight the predicted extreme poor municipalities in Mexico 

How was the data set created?

   1. From what previous works were the data drawn?

   2. How were the data generated, processed, and modified?

      (process 1 of 8)
          Dataset copied.

      (process 2 of 8)
          Dataset copied.

          Data sources used in this process:
              * Server=nrg_2000; Service=esri_sde; Database=environment; User=sde; Version=sde.DEFAULT 

      (process 3 of 8)
          Dataset copied.

          Data sources used in this process:

      (process 4 of 8)
          Dataset copied.

          Data sources used in this process:
              * Server=nrg_2000; Service=esri_sde; Database=socioeconomic; User=sde; Version=sde.DEFAULT 

      (process 5 of 8)
          Dataset copied.

          Data sources used in this process:
              * D:\CIESIN_PROJECT\DATOS_NBI\MEXICO\poverty_mapping\socio_econ\socioeconomic_SDE_mex_poor_muni00 

      (process 6 of 8)
          Metadata imported.

          Data sources used in this process:
              * D:\CIESIN_PROJECT\MAPAS_NBI_POBREZA_DATOS VARIOS\MEXICO_POBREZA2000.shp.xml 

      (process 7 of 8)
          Dataset copied.

          Data sources used in this process:
              * D:\CIESIN_PROJECT\DATOS_NBI\MEXICO\poverty_mapping\socio_econ\socioeconomic_SDE_mex_municipio_pov_model 

      (process 8 of 8)
          Metadata imported.

          Data sources used in this process:
              * D:\CIESIN_PROJECT\MAPAS_NBI_POBREZA_DATOS VARIOS\MEXICO_POBREZA2000_MODEL.shp.xml 

   3. What similar or related data should the user be aware of?



How can someone get a copy of the data set?

    Are there legal restrictions on access or use of the data?

        Access_Constraints: None
        Use_Constraints: None

   1. Who distributes the data set?[Distributor contact information not provided.]

   2. What's the catalog number I need to order this data set?

      Downloadable Data

   3. What legal disclaimers am I supposed to read?

   4. How can I download or order the data?

          * Availability in digital form:

            Data format: 	Size: 4.799

          * Cost to order the data: 

Who wrote the metadata?

Dates:
    Last modified: 10-Oct-2005
Metadata author:
    REQUIRED: The organization responsible for the metadata information.
    c/o REQUIRED: The person responsible for the metadata information.
    REQUIRED: The city of the address., REQUIRED: The state or province of the address. REQUIRED: The ZIP or other postal code of the address.

    REQUIRED: The telephone number by which individuals can speak to the organization or individual. (voice)
Metadata standard:
    FGDC Content Standards for Digital Geospatial Metadata (FGDC-STD-001-1998)
Metadata extensions used:

        * <http://www.esri.com/metadata/esriprof80.html>

Generated by mp version 2.8.6 on Mon Oct 10 10:40:57 2005

Modifications to the Metadata:

Metadata records were modified from its original form, FGDC Content Standards for Digital Geospatial Metadata (FGDC-STD-001-1998)
by CIESIN on 02-Feb-2006 since this data is being released in a tabular data, as opposed to geospatial, file format. 

